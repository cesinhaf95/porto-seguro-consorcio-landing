#!/bin/bash

echo "🚀 Configurando projeto para GitHub..."

# Verificar se git está inicializado
if [ ! -d .git ]; then
    echo "📦 Inicializando repositório Git..."
    git init
fi

# Verificar se há mudanças para commitar
if [ -n "$(git status --porcelain)" ]; then
    echo "📝 Adicionando arquivos ao Git..."
    git add .
    
    echo "💾 Fazendo commit inicial..."
    git commit -m "feat: Porto Seguro consórcio landing page

- Simulador de consórcio para carros e imóveis
- Formulário de captura de leads com validação
- Integração WhatsApp para contato direto
- Interface responsiva com Tailwind CSS
- Backend Express com PostgreSQL
- Validação com Zod e React Hook Form"
else
    echo "✅ Repositório já está atualizado!"
fi

echo ""
echo "🎯 Próximos passos:"
echo "1. Crie um repositório no GitHub: https://github.com/new"
echo "2. Nome sugerido: porto-seguro-consorcio-landing"
echo "3. Execute estes comandos (substitua SEU_USUARIO):"
echo ""
echo "   git remote add origin https://github.com/SEU_USUARIO/porto-seguro-consorcio-landing.git"
echo "   git branch -M main"
echo "   git push -u origin main"
echo ""
echo "📚 Para deploy, consulte o arquivo DEPLOY.md"
echo ""
echo "✨ Projeto pronto para GitHub!"