# 🚀 Guia de Deploy para GitHub

## Preparação do Projeto

### 1. Criar Repositório no GitHub

1. Acesse [GitHub.com](https://github.com) e faça login
2. Clique em "New repository" (botão verde)
3. Nome sugerido: `porto-seguro-consorcio-landing`
4. Descrição: `Landing page para simulação e captação de leads de consórcio Porto Seguro`
5. Mantenha como **Public** (ou Private se preferir)
6. **NÃO** marque "Add a README file" (já temos um)
7. Clique em "Create repository"

### 2. Comandos para Upload

Depois de criar o repositório, execute estes comandos no terminal do Replit:

```bash
# Inicializar Git no projeto
git init

# Adicionar todos os arquivos
git add .

# Fazer o primeiro commit
git commit -m "feat: initial commit - Porto Seguro consórcio landing page"

# Conectar com o repositório GitHub (substitua URL pela sua)
git remote add origin https://github.com/SEU_USUARIO/porto-seguro-consorcio-landing.git

# Enviar para o GitHub
git push -u origin main
```

## 🌐 Opções de Deploy

### 1. Vercel (Recomendado para Frontend)

1. Acesse [vercel.com](https://vercel.com)
2. Conecte sua conta GitHub
3. Selecione o repositório `porto-seguro-consorcio-landing`
4. Configure as variáveis de ambiente:
   - `DATABASE_URL` (URL do PostgreSQL)
   - `NODE_ENV=production`
5. Deploy automático!

**Vantagens:**
- Deploy automático a cada push
- CDN global
- HTTPS gratuito
- Fácil configuração

### 2. Railway (Recomendado para Fullstack)

1. Acesse [railway.app](https://railway.app)
2. Conecte sua conta GitHub
3. Selecione "Deploy from GitHub repo"
4. Escolha o repositório
5. Railway detectará automaticamente Node.js
6. Adicione PostgreSQL como serviço
7. Configure variáveis de ambiente

**Vantagens:**
- PostgreSQL incluído
- Escalabilidade automática
- Logs detalhados
- Deploy automático

### 3. Render

1. Acesse [render.com](https://render.com)
2. Conecte GitHub
3. Crie "New Web Service"
4. Conecte o repositório
5. Configure:
   - Build Command: `npm run build`
   - Start Command: `npm start`
6. Adicione PostgreSQL separadamente

### 4. Heroku

1. Acesse [heroku.com](https://heroku.com)
2. Crie novo app
3. Conecte GitHub
4. Ative deploy automático
5. Adicione PostgreSQL addon:
   ```bash
   heroku addons:create heroku-postgresql:hobby-dev
   ```

## 🔧 Configurações Importantes

### Variáveis de Ambiente

Todas as plataformas precisam dessas variáveis:

```env
DATABASE_URL=postgresql://...
NODE_ENV=production
```

### Build Settings

Para plataformas que precisam:
- **Build Command**: `npm run build`
- **Start Command**: `npm start`
- **Node Version**: 18+

## 📱 Domínio Personalizado

Após o deploy, você pode configurar domínio personalizado:

1. **Vercel**: Project Settings → Domains
2. **Railway**: Settings → Networking → Custom Domain
3. **Render**: Settings → Custom Domains
4. **Heroku**: Settings → Domains

## 🔄 Atualizações Automáticas

Com o repositório no GitHub, qualquer mudança no código será automaticamente deployada quando você fizer:

```bash
git add .
git commit -m "Descrição da mudança"
git push
```

## 🗄️ Backup do Banco

Para produção, configure backup automático do PostgreSQL na plataforma escolhida.

## 📊 Monitoramento

Recomendado adicionar:
- Google Analytics
- Logs de erro (Sentry)
- Uptime monitoring

## ✅ Checklist de Deploy

- [ ] Repositório criado no GitHub
- [ ] Código enviado para GitHub
- [ ] Plataforma de deploy escolhida
- [ ] Variáveis de ambiente configuradas
- [ ] PostgreSQL configurado
- [ ] Site funcionando
- [ ] Formulários testados
- [ ] WhatsApp integration funcionando
- [ ] Domínio configurado (opcional)
- [ ] Analytics configurado (opcional)

## 🆘 Problemas Comuns

### Erro de Build
- Verifique se todas as dependências estão no package.json
- Confirme versão do Node.js (18+)

### Erro de Database
- Confirme DATABASE_URL está correta
- Execute migrations se necessário

### WhatsApp não funciona
- Verifique se o número está correto
- Teste em device móvel

---

**Dica:** Comece com Vercel ou Railway - são as opções mais simples para este tipo de projeto!