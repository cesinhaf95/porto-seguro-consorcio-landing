# 📁 Como Enviar o Projeto para o GitHub

## Passo 1: Criar Repositório no GitHub

1. Acesse **github.com** e faça login
2. Clique no botão **"New"** (verde) ou vá em **github.com/new**
3. Preencha:
   - **Nome**: `porto-seguro-consorcio-landing`
   - **Descrição**: `Landing page para simulação e captação de leads de consórcio`
   - Deixe **Public** marcado
   - **NÃO** marque "Add a README file"
4. Clique em **"Create repository"**

## Passo 2: Copiar URL do Repositório

Após criar, você verá uma página com comandos. Copie a **URL do repositório** que aparece assim:
```
https://github.com/SEU_USUARIO/porto-seguro-consorcio-landing.git
```

## Passo 3: Comandos no Terminal do Replit

Cole estes comandos **um por vez** no terminal do Replit:

```bash
# 1. Inicializar Git
git init
```

```bash
# 2. Adicionar todos os arquivos
git add .
```

```bash
# 3. Fazer o primeiro commit
git commit -m "feat: Porto Seguro consórcio landing page inicial"
```

```bash
# 4. Conectar com seu repositório (SUBSTITUA a URL pela sua)
git remote add origin https://github.com/SEU_USUARIO/porto-seguro-consorcio-landing.git
```

```bash
# 5. Definir branch principal
git branch -M main
```

```bash
# 6. Enviar para o GitHub
git push -u origin main
```

## ✅ Pronto!

Depois do último comando, visite seu repositório no GitHub e verá todos os arquivos lá!

## 🚀 Para Deploy Automático

Recomendo usar **Vercel** (mais fácil):

1. Acesse **vercel.com**
2. Conecte sua conta GitHub
3. Selecione o repositório que você criou
4. Configure apenas a variável `DATABASE_URL`
5. Deploy automático!

## 💡 Dicas

- Se der erro, tente executar um comando por vez
- Para futuras atualizações, use apenas:
  ```bash
  git add .
  git commit -m "Descrição da mudança"
  git push
  ```

**Qualquer dúvida, me chame que te ajudo!**