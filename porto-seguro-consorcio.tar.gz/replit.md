# Overview

This is a Porto Seguro consortium landing page application built with Express.js backend and React frontend. The application provides a single-page lead generation website for selling consortium products (cars, motorcycles, real estate, and heavy vehicles) with integrated WhatsApp contact functionality and lead capture forms. When users click "Ver Créditos Disponíveis" on any product card, it opens a modal form directly instead of navigating to separate product pages, streamlining the user experience.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Framework**: React 18 with Vite as the build tool
- **Routing**: Wouter for client-side routing with dedicated pages for each product category
- **UI Components**: Shadcn/ui component library with Radix UI primitives for consistent design
- **Styling**: Tailwind CSS with custom design system including Porto Seguro branding colors
- **State Management**: TanStack Query for server state management and form handling
- **Form Management**: React Hook Form with Zod validation for lead capture forms

## Backend Architecture
- **Server Framework**: Express.js with TypeScript support
- **API Structure**: RESTful endpoints for lead management (`/api/lead`, `/api/leads`)
- **Development Setup**: Vite middleware integration for hot module replacement during development
- **Error Handling**: Centralized error handling with proper HTTP status codes and JSON responses

## Component Structure
- **Reusable Components**: Modular design with components like Hero, CategoryCard, LeadModal, FaqAccordion
- **Page Components**: Single home page with product category cards that trigger modal forms
- **Shared Components**: Common UI elements using shadcn/ui component library
- **Modal Integration**: CategoryCard components now trigger LeadModal directly instead of navigation

## Data Storage Solutions
- **Database**: PostgreSQL configured with Drizzle ORM
- **Schema Management**: Drizzle migrations in `/migrations` directory
- **Development Storage**: In-memory storage implementation for development/testing
- **Data Models**: Users and Leads tables with proper TypeScript typing

## Lead Management System
- **Lead Capture**: Modal forms with validation for contact information
- **Data Validation**: Zod schemas for both frontend and backend validation
- **Lead Storage**: Database persistence with creation timestamps
- **Form Fields**: Nome (name), WhatsApp, email, CPF, CEP, forma de contato (contact method)
- **Contact Methods**: WhatsApp integration or phone call request options

# External Dependencies

## UI and Styling
- **Shadcn/ui**: Complete component library with Radix UI primitives
- **Tailwind CSS**: Utility-first CSS framework for styling
- **Lucide React**: Icon library for consistent iconography
- **Class Variance Authority**: For component variant management

## Database and ORM
- **Drizzle ORM**: Type-safe database interactions with PostgreSQL
- **Neon Database**: Serverless PostgreSQL database provider
- **Database Connection**: Environment-based configuration via `DATABASE_URL`

## Form and Validation
- **React Hook Form**: Form state management and validation
- **Zod**: Runtime type validation and schema definition
- **Hookform Resolvers**: Integration between React Hook Form and Zod

## Development Tools
- **Vite**: Frontend build tool with hot module replacement
- **TypeScript**: Type safety across the entire application
- **ESBuild**: Fast bundling for production builds

## Analytics and Tracking
- **Google Analytics**: Integrated gtag events for lead submission and WhatsApp clicks
- **Custom Analytics**: Track user interactions for conversion optimization

## Communication
- **WhatsApp Integration**: Direct messaging with pre-filled product and value information
- **Lead Notifications**: Form submissions stored in database for follow-up

## Production Deployment
- **Static Asset Serving**: Express static file serving for production builds
- **Environment Configuration**: Development and production environment separation
- **Build Pipeline**: Vite build process with optimized bundle output