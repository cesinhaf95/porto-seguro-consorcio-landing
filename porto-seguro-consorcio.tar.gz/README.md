# Porto Seguro Consórcio - Landing Page

Uma plataforma moderna para simulação e captação de leads de consórcio da Porto Seguro, com foco em automóveis e imóveis.

## 🚀 Funcionalidades

- **Simulador de Consórcio**: Cálculo automático de parcelas para carros e imóveis
- **Captura de Leads**: Formulário otimizado com integração WhatsApp
- **Interface Responsiva**: Design moderno com Tailwind CSS
- **Validação de Formulários**: Validação robusta com Zod
- **Integração WhatsApp**: Contato direto com leads qualificados

## 🛠️ Tecnologias

### Frontend
- **React 18** com TypeScript
- **Vite** como bundler
- **Tailwind CSS** para estilização
- **Shadcn/ui** para componentes
- **React Hook Form** + **Zod** para formulários
- **TanStack Query** para gerenciamento de estado

### Backend
- **Express.js** com TypeScript
- **Drizzle ORM** para banco de dados
- **PostgreSQL** como banco de dados
- **Zod** para validação de dados

## 📦 Instalação

1. Clone o repositório:
```bash
git clone <url-do-repositorio>
cd porto-seguro-consorcio
```

2. Instale as dependências:
```bash
npm install
```

3. Configure as variáveis de ambiente:
```bash
cp .env.example .env
```

4. Configure a URL do banco de dados PostgreSQL no arquivo `.env`:
```
DATABASE_URL=postgresql://usuario:senha@localhost:5432/porto_consorcio
```

5. Execute as migrações do banco:
```bash
npm run db:migrate
```

6. Inicie o servidor de desenvolvimento:
```bash
npm run dev
```

## 🗄️ Estrutura do Projeto

```
├── client/                 # Frontend React
│   ├── src/
│   │   ├── components/     # Componentes reutilizáveis
│   │   ├── pages/          # Páginas da aplicação
│   │   ├── hooks/          # Hooks customizados
│   │   └── lib/            # Utilitários e configurações
├── server/                 # Backend Express
│   ├── index.ts           # Servidor principal
│   ├── routes.ts          # Rotas da API
│   └── storage.ts         # Interface de armazenamento
├── shared/                 # Código compartilhado
│   └── schema.ts          # Schemas Zod e Drizzle
└── migrations/            # Migrações do banco
```

## 📊 Regras de Negócio

### Carros
- **Faixas de Valor**: 4 opções (até R$ 50k, R$ 50-100k, R$ 100-150k, acima R$ 150k)
- **Parcelas**: Variação de 50 a 90 parcelas conforme valor
- **Redução**: 20% de desconto nas parcelas exibidas

### Imóveis
- **Faixas de Valor**: 4 opções (até R$ 200k, R$ 200-400k, R$ 400-600k, acima R$ 600k)
- **Parcelas**: Fixo em 200 parcelas
- **Taxa Admin**: Variável conforme valor do crédito

## 🔧 Scripts Disponíveis

- `npm run dev` - Inicia servidor de desenvolvimento
- `npm run build` - Build para produção
- `npm run db:migrate` - Executa migrações do banco
- `npm run db:studio` - Abre interface visual do banco

## 📝 Variáveis de Ambiente

```env
DATABASE_URL=postgresql://...
NODE_ENV=development
```

## 🚀 Deploy

O projeto está configurado para deploy no Replit, mas pode ser facilmente adaptado para outras plataformas:

- **Vercel**: Para frontend + serverless functions
- **Railway**: Para fullstack com PostgreSQL
- **Heroku**: Para aplicação completa

## 📱 Integração WhatsApp

O sistema integra diretamente com WhatsApp para contato com leads:
- Número configurado: +55 11 94028-2370
- Mensagem personalizada com produto e faixa de valor
- Fallback para solicitação de ligação

## 🔒 Segurança

- Validação de dados no frontend e backend
- Sanitização de inputs
- Rate limiting nas APIs
- Variáveis de ambiente para dados sensíveis

## 🤝 Contribuição

1. Faça um fork do projeto
2. Crie uma branch para sua feature (`git checkout -b feature/AmazingFeature`)
3. Commit suas mudanças (`git commit -m 'Add some AmazingFeature'`)
4. Push para a branch (`git push origin feature/AmazingFeature`)
5. Abra um Pull Request

## 📄 Licença

Este projeto está sob a licença MIT. Veja o arquivo `LICENSE` para mais detalhes.

## 📞 Contato

Para dúvidas ou suporte, entre em contato através do WhatsApp integrado na plataforma.