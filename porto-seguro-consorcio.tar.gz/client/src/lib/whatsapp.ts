const WHATSAPP_NUMBER = "5511940282370";

export function generateWhatsAppUrl(message: string): string {
  const encodedMessage = encodeURIComponent(message);
  return `https://wa.me/${WHATSAPP_NUMBER}?text=${encodedMessage}`;
}

export function formatWhatsAppMessage(produto: string, valor: number): string {
  const formattedValue = new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL',
    minimumFractionDigits: 0
  }).format(valor);

  return `Olá! Quero uma proposta de consórcio para ${produto} no valor de ${formattedValue}`;
}
