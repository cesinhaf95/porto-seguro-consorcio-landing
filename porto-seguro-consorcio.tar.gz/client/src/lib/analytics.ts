declare global {
  interface Window {
    gtag: (command: string, action: string, parameters?: any) => void;
  }
}

export function trackLeadSubmit(produto: string, valor: number) {
  if (typeof window !== 'undefined' && window.gtag) {
    window.gtag('event', 'submit_lead', {
      event_category: 'form',
      event_label: produto,
      value: valor
    });
  }
}

export function trackWhatsAppClick(produto: string, valor: number) {
  if (typeof window !== 'undefined' && window.gtag) {
    window.gtag('event', 'click_whatsapp', {
      event_category: 'contact',
      event_label: produto,
      value: valor
    });
  }
}

export function trackPageView(page: string) {
  if (typeof window !== 'undefined' && window.gtag) {
    window.gtag('config', 'GA_TRACKING_ID', {
      page_path: page,
    });
  }
}
