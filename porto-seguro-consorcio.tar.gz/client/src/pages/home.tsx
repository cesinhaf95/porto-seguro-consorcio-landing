import { useState } from "react";
import Hero from "@/components/Hero";
import CategoryCard from "@/components/CategoryCard";
import TestimonialCarousel from "@/components/TestimonialCarousel";
import FaqAccordion from "@/components/FaqAccordion";
import LeadModal from "@/components/LeadModal";
import { Car, Home as HomeIcon } from "lucide-react";

const categories = [
  {
    id: "carro",
    title: "Carros",
    description: "De R$ 25.000 a R$ 200.000",
    icon: Car,
    path: "/carro",
    image: "https://images.unsplash.com/photo-1555215695-3004980ad54e?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
    features: ["Sem entrada obrigatória", "Parcelas reduzidas"]
  },
  {
    id: "imovel",
    title: "Imóveis",
    description: "De R$ 70.000 a R$ 900.000", 
    icon: HomeIcon,
    path: "/imovel",
    image: "https://images.unsplash.com/photo-1560518883-ce09059eeffa?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
    features: ["Casa própria sem financiamento", "Sem burocracia bancária"]
  }
];

const whyPortoSeguro = [
  {
    icon: "🛡️",
    title: "Segurança e Tradição",
    description: "Mais de 70 anos no mercado brasileiro, com solidez financeira e credibilidade reconhecida por milhões de clientes."
  },
  {
    icon: "🚫",
    title: "Sem Juros", 
    description: "Diferente do financiamento tradicional, no consórcio você não paga juros, apenas taxa de administração."
  },
  {
    icon: "💰",
    title: "Parcelas Reduzidas",
    description: "Pague apenas 50% do valor da parcela até ser contemplado, facilitando seu orçamento mensal."
  }
];

const howItWorks = [
  {
    step: 1,
    title: "Escolha seu consórcio",
    description: "Selecione a categoria (carro, moto, imóvel ou pesados) e o valor que deseja adquirir."
  },
  {
    step: 2, 
    title: "Pague as parcelas",
    description: "Comece pagando 50% do valor da parcela até ser contemplado com sua carta de crédito."
  },
  {
    step: 3,
    title: "Seja contemplado", 
    description: "Receba sua contemplação por sorteio mensal ou lance, garantindo seu crédito para a compra."
  },
  {
    step: 4,
    title: "Realize seu sonho",
    description: "Use sua carta de crédito para adquirir o bem desejado e continue pagando as parcelas integrais."
  }
];

export default function Home() {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<string>("");

  const handleCreditClick = (productId: string) => {
    setSelectedProduct(productId);
    setIsModalOpen(true);
  };

  return (
    <div className="min-h-screen bg-background">
      <Hero />
      
      {/* Carro Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-8">
            <h2 className="text-2xl md:text-3xl font-bold text-gray-900 mb-4">
              🚗 Consórcio de Carros
            </h2>
            <p className="text-lg text-gray-600">
              Realize o sonho do carro próprio com parcelas que cabem no seu bolso
            </p>
          </div>
          <div className="max-w-lg mx-auto">
            <CategoryCard 
              key={categories[0].id} 
              category={categories[0]}
              onCreditClick={() => handleCreditClick(categories[0].id)}
            />
          </div>
        </div>
      </section>

      {/* Imóvel Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-8">
            <h2 className="text-2xl md:text-3xl font-bold text-gray-900 mb-4">
              🏠 Consórcio de Imóveis
            </h2>
            <p className="text-lg text-gray-600">
              Casa própria sem financiamento e sem burocracia bancária
            </p>
          </div>
          <div className="max-w-lg mx-auto">
            <CategoryCard 
              key={categories[1].id} 
              category={categories[1]}
              onCreditClick={() => handleCreditClick(categories[1].id)}
            />
          </div>
        </div>
      </section>

      {/* Why Porto Seguro */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Por que escolher a Porto Seguro?
            </h2>
            <p className="text-xl text-gray-600">
              Mais de 70 anos de tradição e confiança no mercado brasileiro
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-12 max-w-5xl mx-auto">
            {whyPortoSeguro.map((item, index) => (
              <div key={index} className="text-center">
                <div className="w-20 h-20 bg-primary rounded-full flex items-center justify-center mx-auto mb-6 text-3xl">
                  {item.icon}
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-4">{item.title}</h3>
                <p className="text-gray-600">{item.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* How it Works */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Como funciona o consórcio
            </h2>
            <p className="text-xl text-gray-600">
              Um processo simples e transparente para realizar seus sonhos
            </p>
          </div>
          
          <div className="max-w-4xl mx-auto">
            <div className="grid md:grid-cols-2 gap-8">
              {howItWorks.map((step) => (
                <div key={step.step} className="flex items-start space-x-4">
                  <div className="w-12 h-12 bg-primary text-white rounded-full flex items-center justify-center font-bold text-lg flex-shrink-0">
                    {step.step}
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-gray-900 mb-2">{step.title}</h3>
                    <p className="text-gray-600">{step.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <TestimonialCarousel />
      <FaqAccordion />
      
      {/* CTA Section */}
      <section className="py-16 bg-gradient-hero relative">
        <div className="absolute inset-0 hero-overlay"></div>
        <div className="container mx-auto px-4 text-center relative z-10">
          <div className="max-w-3xl mx-auto text-white">
            <h2 className="text-3xl md:text-4xl font-bold mb-6">
              Pronto para realizar seu sonho?
            </h2>
            <p className="text-xl mb-8 opacity-90">
              Escolha a categoria desejada acima e simule suas parcelas. Com o consórcio Porto Seguro você pode conquistar seus bens de forma planejada e sem juros.
            </p>
          </div>
        </div>
      </section>

      <LeadModal 
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        produto={selectedProduct}
      />
    </div>
  );
}
