import { useState, useEffect } from "react";
import Hero from "@/components/Hero";
import CreditSlider from "@/components/CreditSlider";
import ExampleTable from "@/components/ExampleTable";
import LeadModal from "@/components/LeadModal";
import FaqAccordion from "@/components/FaqAccordion";
import { generateWhatsAppUrl } from "@/lib/whatsapp";
import { trackWhatsAppClick } from "@/lib/analytics";
import { Link } from "wouter";
import { ArrowLeft } from "lucide-react";

const pesadosFaqs = [
  {
    question: "Que tipos de veículos pesados posso adquirir?",
    answer: "Caminhões, ônibus, tratores, máquinas agrícolas, equipamentos de construção civil e outros veículos comerciais pesados, novos ou seminovos de até 10 anos."
  },
  {
    question: "Preciso ser empresa para fazer consórcio de pesados?",
    answer: "Não necessariamente. Pessoa física também pode aderir, desde que comprove renda suficiente e capacidade de pagamento. Para alguns tipos de veículos pode ser exigido registro como MEI ou empresa."
  },
  {
    question: "Como funciona para máquinas importadas?",
    answer: "Máquinas e equipamentos importados podem ser financiados desde que tenham representante oficial no Brasil, certificado de conformidade do INMETRO e documentação de importação regular."
  },
  {
    question: "Posso usar o veículo como garantia?",
    answer: "No consórcio não há alienação fiduciária como no financiamento. Após a contemplação e quitação, o veículo fica livre de ônus, podendo ser usado como garantia em outras operações se necessário."
  }
];

export default function Pesados() {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [creditValue, setCreditValue] = useState(250000);
  const [showWhatsApp, setShowWhatsApp] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setShowWhatsApp(window.scrollY > 200);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleWhatsAppClick = () => {
    const message = `Olá! Quero uma proposta de consórcio para veículos pesados no valor de ${new Intl.NumberFormat('pt-BR', { 
      style: 'currency', 
      currency: 'BRL',
      minimumFractionDigits: 0 
    }).format(creditValue)}`;
    
    const url = generateWhatsAppUrl(message);
    trackWhatsAppClick('pesados', creditValue);
    window.open(url, '_blank');
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Botão Voltar */}
      <section className="py-4 bg-white">
        <div className="container mx-auto px-4">
          <Link href="/">
            <button className="flex items-center text-primary hover:text-blue-800 transition-colors">
              <ArrowLeft size={20} className="mr-2" />
              <span className="font-semibold">Voltar ao início</span>
            </button>
          </Link>
        </div>
      </section>
      
      {/* Imagem do Produto */}
      <section className="w-full">
        <img 
          src="https://images.unsplash.com/photo-1601584115197-04ecc0da31d7?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&h=600" 
          alt="Caminhão - Consórcio Porto Seguro"
          className="w-full h-[40vh] md:h-[45vh] object-cover"
        />
      </section>

      {/* Texto do Produto */}
      <section className="py-12 bg-white">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-2xl md:text-3xl font-bold text-gray-900 mb-3">
            Veículos Pesados sem juros
          </h1>
          <p className="text-lg text-gray-600 mb-8 max-w-xl mx-auto">
            Sem juros, ideal para empreendedores e investimento garantido
          </p>
          <button
            onClick={() => setIsModalOpen(true)}
            className="bg-primary text-white px-8 py-4 rounded-lg font-semibold text-lg hover:bg-blue-800 transition-all transform hover:scale-105 shadow-lg"
          >
            📄 Solicite uma Proposta
          </button>
          <p className="text-gray-600 mt-3 mb-8">Receba uma proposta personalizada em instantes</p>
          
          <div className="grid md:grid-cols-3 gap-6 max-w-3xl mx-auto">
            <div className="bg-gray-50 rounded-lg p-4">
              <span className="text-2xl mb-2 block">🛡️</span>
              <h3 className="font-semibold text-gray-900">Sem Juros</h3>
              <p className="text-gray-600 text-sm">Pague apenas taxa de administração</p>
            </div>
            <div className="bg-gray-50 rounded-lg p-4">
              <span className="text-2xl mb-2 block">🚚</span>
              <h3 className="font-semibold text-gray-900">Para Empreendedores</h3>
              <p className="text-gray-600 text-sm">Investimento no seu negócio</p>
            </div>
            <div className="bg-gray-50 rounded-lg p-4">
              <span className="text-2xl mb-2 block">💰</span>
              <h3 className="font-semibold text-gray-900">Investimento Garantido</h3>
              <p className="text-gray-600 text-sm">Equipamentos para gerar renda</p>
            </div>
          </div>
        </div>
      </section>


      {/* Simulador */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4 max-w-4xl">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Simule seu consórcio de veículos pesados
            </h2>
            <p className="text-xl text-gray-600">
              Ajuste o valor e veja como ficam suas parcelas
            </p>
          </div>

          <div className="bg-white rounded-xl shadow-lg p-8 mb-8">
            <CreditSlider
              min={180000}
              max={360000}
              value={creditValue}
              onChange={setCreditValue}
              label="Valor do crédito para veículos pesados"
            />
            
            <ExampleTable
              creditValue={creditValue}
              months={100}
              category="pesados"
            />

            <div className="mt-8 flex justify-center">
              <button
                onClick={() => setIsModalOpen(true)}
                className="bg-primary text-white px-8 py-3 rounded-md font-semibold hover:bg-blue-800 transition-colors w-full max-w-sm"
              >
                📄 Solicitar Proposta
              </button>
            </div>
          </div>
        </div>
      </section>

      <FaqAccordion faqs={pesadosFaqs} />
      
      <LeadModal 
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        produto="pesados"
        valorCredito={creditValue}
      />
      
      
      {/* Botão Flutuante WhatsApp */}
      {showWhatsApp && (
        <button
          onClick={handleWhatsAppClick}
          className="fixed bottom-0 left-0 right-0 w-full bg-primary text-white py-4 font-semibold text-lg hover:bg-blue-800 transition-all shadow-lg z-50"
        >
          📱 Fale no WhatsApp
        </button>
      )}
    </div>
  );
}
