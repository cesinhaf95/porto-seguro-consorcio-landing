interface ExampleTableProps {
  creditValue: number;
  months: number;
  category: string;
}

export default function ExampleTable({ creditValue, months, category }: ExampleTableProps) {
  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value);
  };

  // Função para calcular as configurações do consórcio baseado na categoria e valor
  const getConsortiumConfig = () => {
    if (category === 'carro' || category === 'moto') {
      if (creditValue >= 25000 && creditValue <= 50000) {
        return { months: 50, taxaAdmin: 0.20, fundoReserva: 0.02 };
      } else if (creditValue >= 52500 && creditValue <= 65000) {
        return { months: 72, taxaAdmin: 0.20, fundoReserva: 0 };
      } else if (creditValue >= 62500 && creditValue <= 125000) {
        return { months: 80, taxaAdmin: 0.18, fundoReserva: 0 };
      } else if (creditValue >= 125000 && creditValue <= 200000) {
        return { months: 90, taxaAdmin: 0.17, fundoReserva: 0 };
      }
    } else if (category === 'imovel') {
      if (creditValue >= 70000 && creditValue <= 140000) {
        return { months: 200, taxaAdmin: 0.23, fundoReserva: 0 };
      } else if (creditValue >= 140000 && creditValue <= 280000) {
        return { months: 200, taxaAdmin: 0.21, fundoReserva: 0 };
      } else if (creditValue >= 280000 && creditValue <= 560000) {
        return { months: 200, taxaAdmin: 0.19, fundoReserva: 0 };
      } else if (creditValue >= 600000 && creditValue <= 900000) {
        return { months: 200, taxaAdmin: 0.175, fundoReserva: 0 };
      }
    } else if (category === 'pesados') {
      if (creditValue >= 180000 && creditValue <= 360000) {
        return { months: 120, taxaAdmin: 0.16, fundoReserva: 0 };
      }
    }
    
    // Valores padrão caso não se encaixe em nenhuma faixa
    return { months: months, taxaAdmin: 0.20, fundoReserva: 0 };
  };

  const config = getConsortiumConfig();
  const taxaTotal = config.taxaAdmin + config.fundoReserva;
  const valorTotal = creditValue * (1 + taxaTotal);
  const parcelaIntegral = valorTotal / config.months;
  const redutorParcelas = 0.20; // 20% de redução
  const parcelaReduzida = parcelaIntegral * (1 - redutorParcelas);

  return (
    <div className="bg-gray-50 p-6 rounded-lg mt-6">
      <h4 className="font-semibold mb-4 text-center">
        Simulação ({config.months} meses):
      </h4>

      <div className="flex justify-center">
        <div className="bg-white p-6 rounded-lg border-2 border-green-200 max-w-sm w-full text-center">
          <span className="text-lg text-gray-700 block mb-2">Sua parcela mensal:</span>
          <div className="text-3xl font-bold text-green-600 mb-2">
            {formatCurrency(parcelaReduzida)}
          </div>
          <span className="text-sm text-gray-600">até contemplação</span>
        </div>
      </div>
      
      <div className="mt-4 text-center">
        <p className="text-xs text-gray-500">
          *Valores aproximados, sujeitos à aprovação e condições contratuais
        </p>
      </div>
    </div>
  );
}
