interface HeroProps {
  title?: string;
  subtitle?: string;
  backgroundImage?: string;
}

export default function Hero({ 
  title = "Seu consórcio com 50% da parcela até a contemplação — sem juros",
  subtitle = "Realize seus sonhos com a segurança e tradição de quem você já conhece. Carros, motos, imóveis e veículos pesados.",
  backgroundImage,
}: HeroProps) {
  const heroStyle = backgroundImage ? 
    { backgroundImage: `url(${backgroundImage})`, backgroundSize: 'cover', backgroundPosition: 'center' } : 
    {};

  return (
    <section 
      className={`relative min-h-[60vh] flex items-start pt-12 overflow-hidden ${
        backgroundImage ? '' : 'bg-gradient-hero'
      }`}
      style={heroStyle}
    >
      <div className="absolute inset-0 hero-overlay"></div>
      <div className="container mx-auto px-4 relative z-10 pt-8">
        <div className="max-w-lg mx-auto text-center text-white px-4">
          <h1 className="text-2xl md:text-4xl font-bold mb-4 leading-tight">
            {title.includes('50%') ? (
              <>
                Seu consórcio com <span className="text-secondary">50% da parcela</span> até a contemplação — <span className="text-secondary">sem juros</span>
              </>
            ) : (
              title
            )}
          </h1>
          <p className="text-base md:text-xl mb-6 opacity-90">
            {subtitle}
          </p>
          <div className="mt-4 grid grid-cols-1 gap-3 text-sm opacity-90">
            <div className="flex items-center justify-center bg-white/10 rounded-lg p-3">
              <span className="mr-2">🛡️</span>
              <span className="font-semibold">Sem Juros</span>
            </div>
            <div className="flex items-center justify-center bg-white/10 rounded-lg p-3">
              <span className="mr-2">💰</span>
              <span className="font-semibold">50% da Parcela até contemplação</span>
            </div>
          </div>
        </div>
      </div>
      <div className="absolute bottom-0 left-0 right-0 h-20 bg-gradient-to-t from-white to-transparent"></div>
    </section>
  );
}
