import { Slider } from "@/components/ui/slider";
import { Label } from "@/components/ui/label";

interface CreditSliderProps {
  min: number;
  max: number;
  value: number;
  onChange: (value: number) => void;
  label: string;
}

export default function CreditSlider({ min, max, value, onChange, label }: CreditSliderProps) {
  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
      minimumFractionDigits: 0
    }).format(value);
  };

  const formatCompact = (value: number) => {
    if (value >= 1000000) {
      return `R$ ${(value / 1000000).toFixed(1)}M`;
    } else if (value >= 1000) {
      return `R$ ${(value / 1000).toFixed(0)}k`;
    }
    return formatCurrency(value);
  };

  return (
    <div className="mb-6">
      <Label className="block text-sm font-medium text-gray-700 mb-2">
        {label}
      </Label>
      <div className="px-3">
        <Slider
          value={[value]}
          onValueChange={(values) => onChange(values[0])}
          min={min}
          max={max}
          step={1000}
          className="w-full"
        />
        <div className="flex justify-between text-sm text-gray-500 mt-1">
          <span>{formatCompact(min)}</span>
          <span>{formatCompact(max)}</span>
        </div>
      </div>
      <div className="text-center mt-4">
        <span className="text-3xl font-bold text-primary">
          {formatCurrency(value)}
        </span>
      </div>
    </div>
  );
}
