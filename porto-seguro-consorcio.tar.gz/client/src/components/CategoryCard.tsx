import { LucideIcon } from "lucide-react";

interface Category {
  id: string;
  title: string;
  description: string;
  icon: LucideIcon;
  path: string;
  image: string;
  features: string[];
}

interface CategoryCardProps {
  category: Category;
  onCreditClick?: () => void;
}

export default function CategoryCard({ category, onCreditClick }: CategoryCardProps) {
  const Icon = category.icon;
  
  return (
    <div className="bg-white rounded-xl shadow-lg border border-gray-100 overflow-hidden">
      <img 
        src={category.image} 
        alt={`${category.title} - consórcio`}
        className="w-full h-40 object-cover"
        loading="lazy"
      />
      <div className="p-4">
        <div className="flex items-center mb-3">
          <div className="text-primary mr-3">
            <Icon size={28} />
          </div>
          <h3 className="text-lg font-bold text-gray-900">{category.title}</h3>
        </div>
        <div className="space-y-1 text-sm text-gray-600 mb-4">
          {category.features.map((feature, index) => (
            <div key={index} className="flex items-center">
              <span className="text-green-500 mr-2 text-base">✓</span>
              <span className="font-medium">{feature}</span>
            </div>
          ))}
        </div>
        <button 
          onClick={onCreditClick}
          className="w-full bg-primary text-white py-3 rounded-lg font-semibold hover:bg-blue-800 transition-colors shadow-md"
        >
          💰 Receber simulação
        </button>
      </div>
    </div>
  );
}
