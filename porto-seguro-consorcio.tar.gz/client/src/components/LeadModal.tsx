import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertLeadSchema } from "@shared/schema";
import type { InsertLead } from "@shared/schema";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { X } from "lucide-react";
import { trackLeadSubmit } from "@/lib/analytics";

interface LeadModalProps {
  isOpen: boolean;
  onClose: () => void;
  produto?: string;
  valorCredito?: number;
}

export default function LeadModal({ isOpen, onClose, produto, valorCredito }: LeadModalProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const {
    register,
    handleSubmit,
    formState: { errors },
    setValue,
    watch,
    reset
  } = useForm<InsertLead>({
    resolver: zodResolver(insertLeadSchema),
    defaultValues: {
      nome: "",
      whatsapp: "",
      cep: "",
      valorCredito: produto === "carro" ? "ate-50mil" : "ate-200mil",
      formaContato: "whatsapp"
    }
  });

  const leadMutation = useMutation({
    mutationFn: async (data: InsertLead) => {
      return apiRequest("POST", "/api/lead", data);
    },
    onSuccess: () => {
      toast({
        title: "Proposta enviada com sucesso!",
        description: "Entraremos em contato em breve.",
      });
      trackLeadSubmit(produto || 'geral', valorCredito || 0);
      queryClient.invalidateQueries({ queryKey: ["/api/leads"] });
      reset();
      onClose();
    },
    onError: (error: any) => {
      toast({
        title: "Erro ao enviar proposta",
        description: error.message || "Tente novamente mais tarde.",
        variant: "destructive"
      });
    }
  });

  const formatPhone = (value: string) => {
    const numbers = value.replace(/\D/g, '');
    if (numbers.length <= 11) {
      return numbers.replace(/(\d{2})(\d{5})(\d{4})/, '($1) $2-$3');
    }
    return value;
  };

  const formatCep = (value: string) => {
    const numbers = value.replace(/\D/g, '');
    if (numbers.length <= 8) {
      return numbers.replace(/(\d{5})(\d{3})/, '$1-$2');
    }
    return value;
  };

  const formatCpf = (value: string) => {
    const numbers = value.replace(/\D/g, '');
    if (numbers.length <= 11) {
      return numbers.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, '$1.$2.$3-$4');
    }
    return value;
  };

  const handlePhoneChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const formatted = formatPhone(e.target.value);
    setValue('whatsapp', formatted);
  };

  const handleCepChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const formatted = formatCep(e.target.value);
    setValue('cep', formatted);
  };

  const handleCpfChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const formatted = formatCpf(e.target.value);
    setValue('cpf', formatted);
  };

  const onSubmit = (data: InsertLead) => {
    if (data.formaContato === "whatsapp") {
      // Abrir WhatsApp
      const message = `Olá! Quero uma proposta de consórcio para ${produto || 'produto'} na faixa de valor: ${data.valorCredito}`;
      
      const whatsappUrl = `https://wa.me/5511940282370?text=${encodeURIComponent(message)}`;
      window.open(whatsappUrl, '_blank');
      
      // Salvar o lead
      leadMutation.mutate(data);
    } else if (data.formaContato === "ligacao") {
      // Salvar o lead primeiro
      leadMutation.mutate({
        ...data,
        formaContato: "ligacao"
      });
      
      // Mostrar mensagem de ligação
      toast({
        title: "Solicitação recebida!",
        description: "Entraremos em contato por telefone em breve. Mantenha seu celular por perto!",
        duration: 5000
      });
      
      handleClose();
    }
  };

  const handleClose = () => {
    reset();
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Solicitar Proposta</DialogTitle>
          <DialogDescription>
            Preencha seus dados para receber uma proposta personalizada do consórcio.
          </DialogDescription>
        </DialogHeader>
        
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
          <div>
            <Label htmlFor="nome">Nome completo *</Label>
            <Input
              id="nome"
              {...register("nome")}
              placeholder="Seu nome completo"
              className={errors.nome ? "border-red-500" : ""}
            />
            {errors.nome && <p className="text-red-500 text-sm mt-1">{errors.nome.message}</p>}
          </div>
          
          <div>
            <Label htmlFor="whatsapp">WhatsApp *</Label>
            <Input
              id="whatsapp"
              type="tel"
              {...register("whatsapp")}
              onChange={handlePhoneChange}
              placeholder="(11) 99999-9999"
              className={errors.whatsapp ? "border-red-500" : ""}
            />
            {errors.whatsapp && <p className="text-red-500 text-sm mt-1">{errors.whatsapp.message}</p>}
          </div>
          
          <div>
            <Label htmlFor="valorCredito">Valor desejado *</Label>
            <Select value={watch("valorCredito")} onValueChange={(value) => setValue("valorCredito", value)}>
              <SelectTrigger className={errors.valorCredito ? "border-red-500" : ""}>
                <SelectValue placeholder="Selecione o valor" />
              </SelectTrigger>
              <SelectContent>
                {produto === "carro" ? (
                  <>
                    <SelectItem value="ate-50mil">Até R$ 50 mil</SelectItem>
                    <SelectItem value="50mil-100mil">R$ 50 mil a R$ 100 mil</SelectItem>
                    <SelectItem value="100mil-150mil">R$ 100 mil a R$ 150 mil</SelectItem>
                    <SelectItem value="acima-150mil">Acima de R$ 150 mil</SelectItem>
                  </>
                ) : (
                  <>
                    <SelectItem value="ate-200mil">Até R$ 200 mil</SelectItem>
                    <SelectItem value="200mil-400mil">R$ 200 mil a R$ 400 mil</SelectItem>
                    <SelectItem value="400mil-600mil">R$ 400 mil a R$ 600 mil</SelectItem>
                    <SelectItem value="acima-600mil">Acima de R$ 600 mil</SelectItem>
                  </>
                )}
              </SelectContent>
            </Select>
            {errors.valorCredito && <p className="text-red-500 text-sm mt-1">{errors.valorCredito.message}</p>}
          </div>
          
          <div>
            <Label htmlFor="cep">CEP</Label>
            <Input
              id="cep"
              {...register("cep")}
              onChange={handleCepChange}
              placeholder="00000-000"
              maxLength={9}
              className={errors.cep ? "border-red-500" : ""}
            />
            {errors.cep && <p className="text-red-500 text-sm mt-1">{errors.cep.message}</p>}
          </div>
          
          
          <div>
            <Label>Forma de Contato</Label>
            <RadioGroup 
              value={watch("formaContato") || "whatsapp"} 
              onValueChange={(value) => setValue("formaContato", value as "whatsapp" | "ligacao")}
              className="mt-2"
            >
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="whatsapp" id="whatsapp" />
                <Label htmlFor="whatsapp" className="font-normal cursor-pointer">
                  📱 Falar agora pelo WhatsApp
                </Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="ligacao" id="ligacao" />
                <Label htmlFor="ligacao" className="font-normal cursor-pointer">
                  📞 Receber uma ligação
                </Label>
              </div>
            </RadioGroup>
          </div>
          
          <div className="pt-4">
            <Button 
              type="submit" 
              disabled={leadMutation.isPending}
              className="w-full"
            >
              {leadMutation.isPending ? "Processando..." : "Continuar"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
