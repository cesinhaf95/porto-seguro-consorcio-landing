import { Link } from "wouter";

export default function Footer() {
  return (
    <footer className="bg-gray-900 text-white py-12">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-4 gap-8">
          <div>
            <div className="flex items-center space-x-2 mb-4">
              <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
                <span className="text-white font-bold">PS</span>
              </div>
              <span className="text-white font-bold text-lg">Porto Seguro</span>
            </div>
            <p className="text-gray-400">
              Mais de 70 anos facilitando a realização dos seus sonhos com segurança e tradição.
            </p>
          </div>
          
          <div>
            <h3 className="font-semibold mb-4">Produtos</h3>
            <ul className="space-y-2 text-gray-400">
              <li><Link href="/carro" className="hover:text-white transition-colors">Consórcio de Carros</Link></li>
              <li><Link href="/moto" className="hover:text-white transition-colors">Consórcio de Motos</Link></li>
              <li><Link href="/imovel" className="hover:text-white transition-colors">Consórcio de Imóveis</Link></li>
              <li><Link href="/pesados" className="hover:text-white transition-colors">Consórcio de Pesados</Link></li>
            </ul>
          </div>
          
          <div>
            <h3 className="font-semibold mb-4">Informações</h3>
            <ul className="space-y-2 text-gray-400">
              <li><a href="#" className="hover:text-white transition-colors">Como Funciona</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Regulamento</a></li>
              <li><a href="#" className="hover:text-white transition-colors">ABAC</a></li>
              <li><a href="#" className="hover:text-white transition-colors">LGPD</a></li>
            </ul>
          </div>
          
          <div>
            <h3 className="font-semibold mb-4">Contato</h3>
            <ul className="space-y-2 text-gray-400">
              <li className="flex items-center">
                <span className="mr-2">📱</span>
                (11) 9 4028-2370
              </li>
              <li className="flex items-center">
                <span className="mr-2">📧</span>
                contato@portoseguro.com.br
              </li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
          <p>&copy; 2024 Porto Seguro. Todos os direitos reservados. CNPJ: 61.198.164/0001-60</p>
        </div>
      </div>
    </footer>
  );
}
