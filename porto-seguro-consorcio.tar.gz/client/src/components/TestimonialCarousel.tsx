import { Card, CardContent } from "@/components/ui/card";

const testimonials = [
  {
    name: "Maria Silva",
    location: "São Paulo, SP",
    content: "Consegui meu carro dos sonhos em apenas 8 meses. As parcelas reduzidas fizeram toda a diferença no meu orçamento!",
    rating: 5
  },
  {
    name: "João Santos", 
    location: "Rio de Janeiro, RJ",
    content: "Atendimento excelente e processo transparente. Recomendo a Porto Seguro para todos os meus amigos.",
    rating: 5
  },
  {
    name: "Ana Costa",
    location: "Belo Horizonte, MG", 
    content: "Minha casa própria saiu do papel! O consórcio Porto Seguro tornou possível o que parecia impossível.",
    rating: 5
  }
];

export default function TestimonialCarousel() {
  return (
    <section className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            O que nossos clientes dizem
          </h2>
          <p className="text-xl text-gray-600">
            Histórias reais de quem realizou o sonho com a Porto Seguro
          </p>
        </div>
        
        <div className="max-w-4xl mx-auto">
          <div className="grid md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <Card key={index} className="shadow-lg">
                <CardContent className="p-6">
                  <div className="flex items-center mb-4">
                    <div className="w-12 h-12 bg-gray-300 rounded-full mr-3"></div>
                    <div>
                      <h4 className="font-semibold text-gray-900">{testimonial.name}</h4>
                      <p className="text-sm text-gray-600">{testimonial.location}</p>
                    </div>
                  </div>
                  <div className="flex text-secondary mb-3">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <span key={i}>⭐</span>
                    ))}
                  </div>
                  <p className="text-gray-600 italic">
                    "{testimonial.content}"
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
