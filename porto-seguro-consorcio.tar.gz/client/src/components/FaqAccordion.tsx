import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";

interface Faq {
  question: string;
  answer: string;
}

interface FaqAccordionProps {
  faqs?: Faq[];
}

const defaultFaqs: Faq[] = [
  {
    question: "O que é um consórcio?",
    answer: "O consórcio é um sistema de autofinanciamento onde um grupo de pessoas se une com o objetivo comum de adquirir um bem. Cada participante contribui mensalmente com uma parcela e é contemplado por sorteio ou lance para receber sua carta de crédito."
  },
  {
    question: "Como funciona a parcela reduzida?",
    answer: "Até ser contemplado, você paga apenas 50% do valor da parcela integral. Após a contemplação, passa a pagar o valor integral. Isso facilita seu orçamento enquanto aguarda receber sua carta de crédito."
  },
  {
    question: "Posso dar lance para ser contemplado mais rápido?",
    answer: "Sim! Além dos sorteios mensais, você pode ofertar um lance (valor adicional) para aumentar suas chances de contemplação. O maior lance do mês ganha a carta de crédito."
  },
  {
    question: "Qual a diferença entre consórcio e financiamento?",
    answer: "No consórcio você não paga juros, apenas taxa de administração. Além disso, pode quitar antecipadamente com desconto e tem flexibilidade para escolher o bem. No financiamento há juros, IOF e o bem fica alienado ao banco."
  },
  {
    question: "Posso usar o FGTS para dar lance?",
    answer: "Para consórcios imobiliários, sim! Você pode utilizar o saldo do FGTS para dar lance ou quitar parcelas, seguindo as regras da Caixa Econômica Federal."
  }
];

export default function FaqAccordion({ faqs = defaultFaqs }: FaqAccordionProps) {
  return (
    <section id="faq" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Perguntas frequentes
          </h2>
          <p className="text-xl text-gray-600">
            Tire suas dúvidas sobre o consórcio Porto Seguro
          </p>
        </div>
        
        <div className="max-w-3xl mx-auto">
          <Accordion type="single" collapsible className="space-y-4">
            {faqs.map((faq, index) => (
              <AccordionItem 
                key={index} 
                value={`item-${index}`}
                className="border border-gray-200 rounded-lg px-6 py-2"
              >
                <AccordionTrigger className="font-semibold text-gray-900 hover:no-underline">
                  {faq.question}
                </AccordionTrigger>
                <AccordionContent className="text-gray-600 pb-4">
                  {faq.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      </div>
    </section>
  );
}
