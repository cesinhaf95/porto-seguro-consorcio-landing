import { Link } from "wouter";

export default function Header() {
  const handleWhatsAppClick = () => {
    window.open("https://wa.me/5511940282370?text=Olá!%20Quero%20informações%20sobre%20consórcio%20Porto%20Seguro", '_blank');
  };

  return null;
}
